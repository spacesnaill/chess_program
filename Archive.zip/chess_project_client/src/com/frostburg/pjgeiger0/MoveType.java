package com.frostburg.pjgeiger0;

public enum MoveType {
    NONE, NORMAL, KILL
}